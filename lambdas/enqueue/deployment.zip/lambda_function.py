import json
import boto3
import logging
import os
from urllib.parse import parse_qs

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize SQS client
sqs = boto3.client('sqs')

# Get queue URL from environment variable or hardcode it
QUEUE_URL = os.environ.get('SQS_QUEUE_URL', 'https://sqs.us-east-1.amazonaws.com/071214564206/gpu-task-queue')

def lambda_handler(event, context):
    """
    Lambda function to enqueue PDF URLs to SQS for GPU processing.
    
    Expected request format:
    - URL query parameter: pdf_url
    - Or JSON body with pdf_url field
    """
    logger.info(f"Received event: {json.dumps(event)}")
    
    # Extract PDF URL from the event
    pdf_url = None
    
    # Check if it's from API Gateway
    if 'queryStringParameters' in event and event['queryStringParameters']:
        # Get from query parameters
        pdf_url = event['queryStringParameters'].get('pdf_url')
    elif 'body' in event and event['body']:
        # Try to get from body if it's JSON
        try:
            body = json.loads(event['body'])
            pdf_url = body.get('pdf_url')
        except (json.JSONDecodeError, TypeError):
            # If not JSON, try to parse as form data
            try:
                if isinstance(event['body'], str):
                    form_data = parse_qs(event['body'])
                    pdf_url = form_data.get('pdf_url', [None])[0]
            except Exception as e:
                logger.error(f"Error parsing form data: {str(e)}")
    
    # Validate PDF URL
    if not pdf_url:
        logger.error("No PDF URL provided")
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Missing pdf_url parameter'})
        }
    
    # Create a message for SQS
    message = {
        'pdf_url': pdf_url,
        'task_id': context.aws_request_id,  # Use Lambda request ID as task ID
        'timestamp': context.invoked_function_arn  # Include function ARN for tracking
    }
    
    try:
        # Send message to SQS
        response = sqs.send_message(
            QueueUrl=QUEUE_URL,
            MessageBody=json.dumps(message)
        )
        
        logger.info(f"Message sent to SQS: {response['MessageId']}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'success': True,
                'message': 'PDF URL added to processing queue',
                'task_id': context.aws_request_id,
                'sqs_message_id': response['MessageId']
            })
        }
    
    except Exception as e:
        logger.error(f"Error sending message to SQS: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': f'Failed to enqueue task: {str(e)}'})
        }